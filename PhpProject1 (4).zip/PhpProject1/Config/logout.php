<?php
session_start();
session_destroy();
?>
<script type="text/javascript">
                alert("Log out successful");
            window.location="../index.php"

              </script> 