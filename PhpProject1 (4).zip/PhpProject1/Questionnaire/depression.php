<?php
include '../Config/connection.php';
session_start();
//$user= $_SESSION['user'];
$date= date("d/m/Y");
$username=$_SESSION['username'];
//if (isset($_SESSION['name']))
  //    echo $_SESSION['name'];
    //  echo $_SESSION['username'];
      $today=strtotime ("today");
//echo $today;
?>
<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>CodePen - Material Inspired Checkboxes and Radio Groups</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
  <link rel="stylesheet" href="./quest.css">

</head>
<body>
<!-- partial:index.partial.html -->
  
  
  
  <h2>Part 2 of 4</h2>
  

     
  <form class="form" action="" method="post">
    <h3>During the last week, how often were you bothered by:</h3>
      <?php
      for($i=5 ; $i<9 ;$i++){
      $q= "select * from questions where questionid = $i";
      $query= mysqli_query($db, $q);
      
      while ($rows= mysqli_fetch_array($query)){ 
      
      ?>
      
          <h4><?php echo $rows['question'] ?> </h4>
          
          
          
          
    <?php
    
        $q= "select * from answers where answ_id= $i";
        $query= mysqli_query($db, $q);
      
      while ($rows= mysqli_fetch_array($query)){   
          $answ_id=$rows['answ_id'];
          $aid=$rows['aid'];
          $answer=$rows['answer'];


          ?>
          
  <div class="inputGroup">
         <?php  echo " <input type='radio' id='anscheck[".$aid."]'name='anscheck[".$answ_id."]' value='$answer'>";
?>    <?php echo "<label for='anscheck[".$aid."]'>".$answer."</label>" ?>
              
          
          </div>
          <?php
      }
      
      }
      
      }
      ?>
            </div>
            <input type="submit" name="submit" value="Next Section" style="float: right">
      </form>

       <?php
if (isset($_POST['submit'])) {
    
    if (!empty($_POST['anscheck'])) {
        
        $count= count($_POST['anscheck']);
        $tech= $_POST['anscheck'];
        
        echo "out of 4 you have selected ".$count." options";
        
        $result=0;
        $i=0;
        
        
        $q= "select * from answers";
      $query= mysqli_query($db, $q);
      $button=$_POST['anscheck'];
        
       // while($rows = mysqli_fetch_array($query)) {

            //$checked= $rows['answer']==$button; 
        //while(isset($_POST['submit'])){ 
      foreach($button as $button) {

           if ($button=="Nearly everyday") {
                $result+=4;
                
            } else if ($button=="Never") {
                $result+=1;
                
            }  else if ($button=="A few days") {
                $result+=2;
                
            }  else if ($button=="More than half the days") {
                $result+=3;
                
            }
            //$i++;
            echo "$button";
        
      }

            


            
        
        }
                echo "<br> Total score is ".$result;
                echo "<br> today date is ".$date;
                mysqli_query($db,'SET foreign_key_checks = 0');
               $sql = "INSERT INTO `questionnaire`(`symptom`,`score`, `user_username`, `datetaken`, `time`) VALUES ('depression','$result','$username','$date','$today')  ";

                $res=mysqli_query($db,$sql);
                mysqli_query($db,'SET foreign_key_checks = 1');

if ($res){



    ?>
    <script type="text/javascript">
    alert("Data Inserted");
    window.location="sdsymp.php"

    </script>

    <?php
    }

    else 
    {
    ?>
    <script type="text/javascript">
    alert("Insertion failed");
    window.location="depression.php"

    </script>

    <?php

      }
           }


   
?>




<link href="https://fonts.googleapis.com/css?family=Fira+Sans" rel="stylesheet">
<!-- partial -->
  
</body>
</html>
