<?php
include '../Config/connection.php';
include '../Homedash/sidebarnav.php';
error_reporting(E_ERROR | E_PARSE);// disables the dispalying of errors

//$date= date("d/m/Y");
//echo 'sessions name'. $name;
//echo 'today date'. $date;
 //if (isset($_SESSION['name']))
 //     echo $_SESSION['name'];
 //     echo "<br>".$_SESSION['username'];
 //echo "<br>".$_SESSION['firstname'];
 $name=$_SESSION['username'];

 ?>

<?php
    $dataPoints = array();
    
    $query1="SELECT score FROM questionnaire WHERE symptom='anxiety' && user_username='$name' ";
    $res1=  mysqli_query($db, $query1);
    
    
    while ($row = mysqli_fetch_assoc($res1)) {		
		array_push($dataPoints, $row["score"]);
	}
    
    $a = array_filter($dataPoints);
    $average = array_sum($a)/count($a);
   // echo "Average score of anxiety= ".$average;

        
        
        
 $dataPoints2 = array();
    
    $query2="SELECT score FROM questionnaire WHERE symptom='depression' && user_username='$name' ORDER BY time ";
    $res2=  mysqli_query($db, $query2);
    
    
    while ($row = mysqli_fetch_assoc($res2)) {		
		array_push($dataPoints2,$row["score"]);
	}
        
        
    $a2 = array_filter($dataPoints2);
    $average2 = array_sum($a2)/count($a2);
   // echo "Average score of depression= ".$average. "\n";
    

$dataPoints3 = array();
    
    $query3="SELECT score,datetaken FROM questionnaire WHERE symptom='sdisorder' && user_username='$name' ORDER BY time ";
    $res3=  mysqli_query($db, $query3);
    
    
    while ($row = mysqli_fetch_assoc($res3)) {		
		array_push($dataPoints3, $row["score"]);
	}
    

        
    $a3 = array_filter($dataPoints3);
    $average3 = array_sum($a3)/count($a3);
    //echo "Average score of somatic disorders= ".$average. "\n";
    
    
$dataPoints4 = array();
    
    $query4="SELECT score,datetaken FROM questionnaire WHERE symptom='subabuse' && user_username='$name' ORDER BY time ";
    $res4=  mysqli_query($db, $query4);
    
    
    while ($row = mysqli_fetch_assoc($res4)) {		
		array_push($dataPoints4, $row["score"]);
	}
    
    $a4 = array_filter($dataPoints4);
    $average4 = array_sum($a4)/count($a4);
    //echo "Average score of substance abuse= ".$average4. "\n";
?>

<?php
 $last1 = array();
    
    $query5="SELECT score,datetaken FROM questionnaire WHERE symptom='anxiety' && user_username='$name' ORDER BY time DESC LIMIT 2";
    $res5=  mysqli_query($db, $query5);
    
    
    while ($row = mysqli_fetch_assoc($res5)) {		
		array_push($last1, $row["score"]);
	}
    
    $a5 = array_filter($last1);
    $average5 = array_sum($a5)/count($a5);
    //echo "Average score of substance abuse= ".$average4. "\n";
    
    
    
    
    
     $last2 = array();
    
    $query6="SELECT score,datetaken FROM questionnaire WHERE symptom='depression' && user_username='$name' ORDER BY time DESC LIMIT 2";
    $res6=  mysqli_query($db, $query6);
    
    
    while ($row = mysqli_fetch_assoc($res6)) {		
		array_push($last2, $row["score"]);
	}
    
    $a6 = array_filter($last2);
    $average6 = array_sum($a6)/count($a6);
    //echo "Average score of substance abuse= ".$average4. "\n";

    
    
     $last3 = array();
    
    $query7="SELECT score,datetaken FROM questionnaire WHERE symptom='sdisorder' && user_username='$name' ORDER BY time DESC LIMIT 2";
    $res7=  mysqli_query($db, $query7);
    
    
    while ($row = mysqli_fetch_assoc($res7)) {		
		array_push($last3, $row["score"]);
	}
    
    $a7 = array_filter($last3);
    $average7 = array_sum($a7)/count($a7);
    //echo "Average score of substance abuse= ".$average4. "\n";
    
    
    
    
     $last4 = array();
    
    $query8="SELECT score,datetaken FROM questionnaire WHERE symptom='subabuse' && user_username='$name' ORDER BY time DESC LIMIT 2";
    $res8=  mysqli_query($db, $query8);
    
    
    while ($row = mysqli_fetch_assoc($res8)) {		
		array_push($last4, $row["score"]);
	}
    
    $a8 = array_filter($last4);
    $average8 = array_sum($a8)/count($a8);
    //echo "Average score of substance abuse= ".$average4. "\n";
?>

  <!-- sidebar-wrapper  -->

  <main class="page-content" style="background-color: #F9F7F6;">
    <div class="container-fluid" style=" text-align: center;">
        <img id="diary-icon" src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTVCkbWpJfDlBWhZ6KBqkdxjHraCmvrBeyE4RszR9Y37HDqIM0i&usqp=CAU" >
        <h1>Home</h1>
      <hr>
      <div class="row">
        <div class="form-group col-md-12">
            <img id="diary-icon" style="height: 80px"src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcStHHYb6iWNSyl0BikLH97PUYjRijz9GnPdeOx_HWqxYHCkgJHc&usqp=CAU" >

            <h3>News Feed</h3>
            <?php


$xml=("https://news.google.com/rss/topics/CAAqIQgKIhtDQkFTRGdvSUwyMHZNR3QwTlRFU0FtVnVLQUFQAQ/sections/CAQiR0NCQVNMd29JTDIwdk1HdDBOVEVTQldWdUxVZENJZzhJQkJvTENna3ZiUzh3TTNnMk9XY3FDeElKTDIwdk1ETjROamxuS0FBKikIAColCAoiH0NCQVNFUW9JTDIwdk1HdDBOVEVTQldWdUxVZENLQUFQAVAB?hl={lang}");


$xmlDoc = new DOMDocument();
$xmlDoc->load($xml);

//get elements from "<channel>"
$channel=$xmlDoc->getElementsByTagName('channel')->item(0);
$channel_title = $channel->getElementsByTagName('title')
->item(0)->childNodes->item(0)->nodeValue;
$channel_link = $channel->getElementsByTagName('link')
->item(0)->childNodes->item(0)->nodeValue;
$channel_desc = $channel->getElementsByTagName('description')
->item(0)->childNodes->item(0)->nodeValue;

//output elements from "<channel>"
echo("<p><a href='" . $channel_link
  . "'>" . $channel_title . "</a>");
echo("<br>");
echo($channel_desc . "</p>");

//get and output "<item>" elements
$x=$xmlDoc->getElementsByTagName('item');
for ($i=0; $i<=5; $i++) {
  $item_title=$x->item($i)->getElementsByTagName('title')
  ->item(0)->childNodes->item(0)->nodeValue;
  $item_link=$x->item($i)->getElementsByTagName('link')
  ->item(0)->childNodes->item(0)->nodeValue;
  $item_desc=$x->item($i)->getElementsByTagName('description')
  ->item(0)->childNodes->item(0)->nodeValue;
  echo ("<p><a href='" . $item_link
  . "'>" . $item_title . "</a>");
  echo ("<br>");
  echo ($item_desc . "</p>");
}
?>
            
        </div>
        <div class="form-group col-md-12">
          
        </div>
      </div>
      
      <hr>
      <div class="row">
        <div class="form-group col-md-12">
            
            <img id="diary-icon" src="https://p.kindpng.com/picc/s/255-2559408_transparent-sales-icon-png-transparent-background-trend-icon.png" style="height: 100px; " >
      
            
       <table class="table table-hover" style="text-align: left">
    <thead class="thead-light">
      <tr>
          <th colspan="5"><h3 style="padding: auto; text-align: center">My trends</h3></th>
        
      </tr>
    </thead>
    <tbody>
      <tr>
          <th>Mental Illness</th>
          <th style="text-align: center">Total Average</th>
          <th style="text-align: center">Average of last 2 assessments</th>
          <th style="text-align: center">Trend</th>
          <th>Status</th>
          
        
      
    </tr>
   
    
    <tr>
        <td>Anxiety</td>
        <td style="text-align: center; color: "><?php echo $average;?></td>
        <td style="text-align: center"><?php echo $average5;?></td>
        <td style="text-align: center"><?php
        
        switch (true) {
    case $average5 < $average:
           echo " <img id='diary-icon' src='https://www.kindpng.com/picc/m/10-101602_down-green-picture-arrow-png-green-down-arrow.png' style='height: 20px;' >";
        break;

    case $average5 > $average:
       echo "<img id='diary-icon' src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAkFBMVEX/////AAD/kZH/+vr/+fn/pKT/pqb/qKj/oqL/5OT/xsb/qqr/nZ3/v7//rq7/paX/6en/l5f/UVH/zs7/Njb/urr/tLT/c3P/mZn/2Nj/S0v/09P/Rkb/y8v/KCj/HR3/fn7/8PD/a2v/Y2P/W1v/IyP/ERH/hIT/b2//XV3/39//QED/Ojr/Jyf/Ly//iYnilW/dAAAGSklEQVR4nN2d2ULbMBBFmSZpWAIN+1rCEihLC///d8WYJU5sa5uZO9J5LCDN7fEIySTx2poyJ9oTarNF1+gShCG6Qpcgy4iocIlvAekYXYQklUKiKboMQd4DlixxvU5YsMSPgPSALkSKyWfCYiV+BaQbdCkyfCsk2kAXI8JCwDIlLiosU2IjIN2iy+HnpJmwQIlLAcuTuKyQ6AldEjMrAUuTuKqwNIktAekRXRQnu20JS5I4aA1Ic3RdfLQrLEhih8KCJHYpJDpFl8ZEZ0DaQ5fGQ7fCQiR2dmExEvsUFiGxV2EREn/0J8xfokMh0Rm6wlRcConO0SWm4VSYvUS3wswlDj0C5i3RR2HWEj26sOICXWc8fgqJ9tGFxuLVhVlL9FWYrURvhdlK9FeYqUTPhbTmGV1tDCEKs5QY0IWZSgxTmKHEQIUZSgxVSPQbXXIYQQtpzV90zWGEK8xMYnAXZicxRmFWEqMUZiUxTiHRJrpwXyIW0poDdOW+xCrMRmJkF2YkMV5hJhITFGYiMUVhFhKjF9KaF3T9btIUEm2jA7hI6sIsJKYqNC8xsQszkJiu0LhEBoVEl+gUfXAoNC0xeSGtMSyRR6FhiSxdWGFWIpdCsxLZFBLdobO0w6fQqESmhbTmHzpNG5wKTUpk7MIKg53Iq5DoEB1oGWaFRDN0omW4FZqTyLqQ1hjrRH6FxiSyd2GFKYkSCk1JFFFoajmVUWhIosBCWmNGopRCMxKFurDCiEQ5hUYkCiokukenq5BUSHSEjie4kNYY6ERZhQYkinZhBVyitEK4RHGF8OVUXiFYooJCsEQNhVCJKgqhEnUUAiUqKQRK1FIIk6imECZRTyFIoqJCkERNhUQ7+gFVFb6hn1BXIUCitkL9TtRWqC5RXSFpd6K+QmWJCIW6EhEKVSViFGpK7P8YPTnUJKIU6klEKdSTCAuoJRGnkGhLIyCuCys0EiIVqnQiVqGGRKxCjU4EB5SXiFYoLhHdhRWyCdueU6GNqEQLCmUlWlAoKxGd7QO5gDYUEo3FEqKTfSEVcOKeWgmpTkTnWkAmoB2FUp2ITtVAIqCVhbTmp0BCdKYl+ANa6sIK/k5EJ1qBO6A1hfydiM7TAm9AewqJfrEmRKdphTOgRYW8nYjO0gFfQJsKOTsRnaQTroBWFRKNmBKic/TAE3AdHaMHnk5Ep+iFI6BlhTydiM7gID2gbYUcEtEJnKQGHKEDOEldTtH1e5AW0HoXVqR1Irp6L0pXmCYRXbsn8QHtL6Q18RLRlXtTusJ4iei6AyhdYaxEdNVBxAT8iS46iBiJ6JoDKV1hjEShQl4mM6GRQwP+EqnisXpS5eaeyNjrBhS+Tj8G37iSGD4s4Jh9/lnjVfZDgVNLWCdyzz5fffLf9gX3JECFVxutszwd804TIpFz3vvRoHOeIe8L4yEKz1wP4To84JvMfzllm/LqyWO281u2+XwDbjHNNxl6TnjN9b5i305kmew57LP/dy5ZZvWbjEPhw2lQvor9OcO8fhLT59m9Ds5XMf2TPrXPPKkKD1I+N3acui/3WU7TZrg9T8hXkbovd8+wkzL8j7jLs0navtzdifFjX7K9g3UwuY8vwzV4tML5Ple+d+L35S6JkcP+mTrGDefpIbKW/mGjFM4kXji/Fr0v75cYcf3vST7gNmpf3jdguMKOox8fEfvyvksqUOH9evfRj4/r19CI3WMdBY1zofdcrcB9ebfEEIXHPkc/PsL25V2jBCg88T368RGyL++S6KvwL+iZDAP/fXn7AJ4Kb8KPfnxsnvkV2f4mU6//IJa9dQqe+/K2H/VQeAB/UEHFcN2jndre2ub8seSjHx/bzxESXQpf0ZdnE+f98lWJvV3Id/TjY+h42+7y9x/2fC/z0Y+P3n358nLarVDg6MfH6Y2vxC6FM5UPSEuh+355s/R2hXurf/WzyFHHvnzxe1oVmr48m5w/uiTerV6eY42jHx/TtkPk95dXFIremZBiZ6XVvn/HLV3H4ncmpPi9fL/88wvbjctT5c6EFEuHyE+JCwqdf5Q2z2C8uMGu/+1bYbaXZ5OFP+7Uh6GXj8uz5zUTufF1iHz/NP7NfFfPHgaj+y+JB+Vcnk3e73jM3lZYusvsl7s/T28X6/bartWjEQuDrfl/4nRzvYB5J80AAAAASUVORK5CYII=' style='height: 20px; ' >";
        break;

    default:
        echo "<img id='diary-icon' src='https://static.thenounproject.com/png/645172-200.png' style='height: 20px; ' >";  
        break;
}
        
         
          ?>  
            </td>  
        <td><?php
        
        switch (true) {
    case $average <= 4:
        echo "<font color='green'>Low</p>";
        break;

    case $average >4 && $average <=8:
        echo "<font color='gold'>Mild</p>";
        break;
    case $average >8 && $average <=12:
        echo "<font color='orange'>Moderate</p>";
        break;
    case $average >12 && $average <=16:
        echo "<font color='red'>Severe</p>";
        break;

    default:
           echo "N/A";
        break;
}
        
         
          ?>  </td>
        
          
        
      
    </tr>

    
     <tr>
        <td>Depression</td>
        <td style="text-align: center"><?php echo $average2;?></td>
        <td style="text-align: center"><?php echo $average6;?></td>
        <td style="text-align: center"><?php
         switch (true) {
    case $average6 < $average2:
           echo " <img id='diary-icon' src='https://www.kindpng.com/picc/m/10-101602_down-green-picture-arrow-png-green-down-arrow.png' style='height: 20px;' >";
        break;

    case $average6 > $average2:
       echo "<img id='diary-icon' src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAkFBMVEX/////AAD/kZH/+vr/+fn/pKT/pqb/qKj/oqL/5OT/xsb/qqr/nZ3/v7//rq7/paX/6en/l5f/UVH/zs7/Njb/urr/tLT/c3P/mZn/2Nj/S0v/09P/Rkb/y8v/KCj/HR3/fn7/8PD/a2v/Y2P/W1v/IyP/ERH/hIT/b2//XV3/39//QED/Ojr/Jyf/Ly//iYnilW/dAAAGSklEQVR4nN2d2ULbMBBFmSZpWAIN+1rCEihLC///d8WYJU5sa5uZO9J5LCDN7fEIySTx2poyJ9oTarNF1+gShCG6Qpcgy4iocIlvAekYXYQklUKiKboMQd4DlixxvU5YsMSPgPSALkSKyWfCYiV+BaQbdCkyfCsk2kAXI8JCwDIlLiosU2IjIN2iy+HnpJmwQIlLAcuTuKyQ6AldEjMrAUuTuKqwNIktAekRXRQnu20JS5I4aA1Ic3RdfLQrLEhih8KCJHYpJDpFl8ZEZ0DaQ5fGQ7fCQiR2dmExEvsUFiGxV2EREn/0J8xfokMh0Rm6wlRcConO0SWm4VSYvUS3wswlDj0C5i3RR2HWEj26sOICXWc8fgqJ9tGFxuLVhVlL9FWYrURvhdlK9FeYqUTPhbTmGV1tDCEKs5QY0IWZSgxTmKHEQIUZSgxVSPQbXXIYQQtpzV90zWGEK8xMYnAXZicxRmFWEqMUZiUxTiHRJrpwXyIW0poDdOW+xCrMRmJkF2YkMV5hJhITFGYiMUVhFhKjF9KaF3T9btIUEm2jA7hI6sIsJKYqNC8xsQszkJiu0LhEBoVEl+gUfXAoNC0xeSGtMSyRR6FhiSxdWGFWIpdCsxLZFBLdobO0w6fQqESmhbTmHzpNG5wKTUpk7MIKg53Iq5DoEB1oGWaFRDN0omW4FZqTyLqQ1hjrRH6FxiSyd2GFKYkSCk1JFFFoajmVUWhIosBCWmNGopRCMxKFurDCiEQ5hUYkCiokukenq5BUSHSEjie4kNYY6ERZhQYkinZhBVyitEK4RHGF8OVUXiFYooJCsEQNhVCJKgqhEnUUAiUqKQRK1FIIk6imECZRTyFIoqJCkERNhUQ7+gFVFb6hn1BXIUCitkL9TtRWqC5RXSFpd6K+QmWJCIW6EhEKVSViFGpK7P8YPTnUJKIU6klEKdSTCAuoJRGnkGhLIyCuCys0EiIVqnQiVqGGRKxCjU4EB5SXiFYoLhHdhRWyCdueU6GNqEQLCmUlWlAoKxGd7QO5gDYUEo3FEqKTfSEVcOKeWgmpTkTnWkAmoB2FUp2ITtVAIqCVhbTmp0BCdKYl+ANa6sIK/k5EJ1qBO6A1hfydiM7TAm9AewqJfrEmRKdphTOgRYW8nYjO0gFfQJsKOTsRnaQTroBWFRKNmBKic/TAE3AdHaMHnk5Ep+iFI6BlhTydiM7gID2gbYUcEtEJnKQGHKEDOEldTtH1e5AW0HoXVqR1Irp6L0pXmCYRXbsn8QHtL6Q18RLRlXtTusJ4iei6AyhdYaxEdNVBxAT8iS46iBiJ6JoDKV1hjEShQl4mM6GRQwP+EqnisXpS5eaeyNjrBhS+Tj8G37iSGD4s4Jh9/lnjVfZDgVNLWCdyzz5fffLf9gX3JECFVxutszwd804TIpFz3vvRoHOeIe8L4yEKz1wP4To84JvMfzllm/LqyWO281u2+XwDbjHNNxl6TnjN9b5i305kmew57LP/dy5ZZvWbjEPhw2lQvor9OcO8fhLT59m9Ds5XMf2TPrXPPKkKD1I+N3acui/3WU7TZrg9T8hXkbovd8+wkzL8j7jLs0navtzdifFjX7K9g3UwuY8vwzV4tML5Ple+d+L35S6JkcP+mTrGDefpIbKW/mGjFM4kXji/Fr0v75cYcf3vST7gNmpf3jdguMKOox8fEfvyvksqUOH9evfRj4/r19CI3WMdBY1zofdcrcB9ebfEEIXHPkc/PsL25V2jBCg88T368RGyL++S6KvwL+iZDAP/fXn7AJ4Kb8KPfnxsnvkV2f4mU6//IJa9dQqe+/K2H/VQeAB/UEHFcN2jndre2ub8seSjHx/bzxESXQpf0ZdnE+f98lWJvV3Id/TjY+h42+7y9x/2fC/z0Y+P3n358nLarVDg6MfH6Y2vxC6FM5UPSEuh+355s/R2hXurf/WzyFHHvnzxe1oVmr48m5w/uiTerV6eY42jHx/TtkPk95dXFIremZBiZ6XVvn/HLV3H4ncmpPi9fL/88wvbjctT5c6EFEuHyE+JCwqdf5Q2z2C8uMGu/+1bYbaXZ5OFP+7Uh6GXj8uz5zUTufF1iHz/NP7NfFfPHgaj+y+JB+Vcnk3e73jM3lZYusvsl7s/T28X6/bartWjEQuDrfl/4nRzvYB5J80AAAAASUVORK5CYII=' style='height: 20px; ' >";
        break;

    default:
        echo "<img id='diary-icon' src='https://static.thenounproject.com/png/645172-200.png' style='height: 20px; ' >";  
        break;
}
         
          ?>  
            </td>  
        <td><?php
        
        switch (true) {
    case $average2 <= 4:
        echo "<font color='green'>Low</p>";
        break;

    case $average2 >4 && $average2 <=8:
        echo "<font color='gold'>Mild</p>";
        break;
    case $average2 >8 && $average2 <=12:
        echo "<font color='orange'>Moderate</p>";
        break;
    case $average2 >12 && $average2 <=16:
        echo "<font color='red'>Severe</p>";
        break;

    default:
           echo "N/A";
        break;
}
        
         
          ?>  </td>
        
          
        
      
    </tr>
    
    
    
     <tr>
        <td>Somatic Disorder</td>
        <td style="text-align: center"><?php echo $average3;?></td>
        <td style="text-align: center"><?php echo $average7;?></td>
        <td style="text-align: center"><?php
        
         
        switch (true) {
    case $average7 < $average3:
           echo " <img id='diary-icon' src='https://www.kindpng.com/picc/m/10-101602_down-green-picture-arrow-png-green-down-arrow.png' style='height: 20px;' >";
        break;

    case $average7 > $average3:
        echo "<img id='diary-icon' src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAkFBMVEX/////AAD/kZH/+vr/+fn/pKT/pqb/qKj/oqL/5OT/xsb/qqr/nZ3/v7//rq7/paX/6en/l5f/UVH/zs7/Njb/urr/tLT/c3P/mZn/2Nj/S0v/09P/Rkb/y8v/KCj/HR3/fn7/8PD/a2v/Y2P/W1v/IyP/ERH/hIT/b2//XV3/39//QED/Ojr/Jyf/Ly//iYnilW/dAAAGSklEQVR4nN2d2ULbMBBFmSZpWAIN+1rCEihLC///d8WYJU5sa5uZO9J5LCDN7fEIySTx2poyJ9oTarNF1+gShCG6Qpcgy4iocIlvAekYXYQklUKiKboMQd4DlixxvU5YsMSPgPSALkSKyWfCYiV+BaQbdCkyfCsk2kAXI8JCwDIlLiosU2IjIN2iy+HnpJmwQIlLAcuTuKyQ6AldEjMrAUuTuKqwNIktAekRXRQnu20JS5I4aA1Ic3RdfLQrLEhih8KCJHYpJDpFl8ZEZ0DaQ5fGQ7fCQiR2dmExEvsUFiGxV2EREn/0J8xfokMh0Rm6wlRcConO0SWm4VSYvUS3wswlDj0C5i3RR2HWEj26sOICXWc8fgqJ9tGFxuLVhVlL9FWYrURvhdlK9FeYqUTPhbTmGV1tDCEKs5QY0IWZSgxTmKHEQIUZSgxVSPQbXXIYQQtpzV90zWGEK8xMYnAXZicxRmFWEqMUZiUxTiHRJrpwXyIW0poDdOW+xCrMRmJkF2YkMV5hJhITFGYiMUVhFhKjF9KaF3T9btIUEm2jA7hI6sIsJKYqNC8xsQszkJiu0LhEBoVEl+gUfXAoNC0xeSGtMSyRR6FhiSxdWGFWIpdCsxLZFBLdobO0w6fQqESmhbTmHzpNG5wKTUpk7MIKg53Iq5DoEB1oGWaFRDN0omW4FZqTyLqQ1hjrRH6FxiSyd2GFKYkSCk1JFFFoajmVUWhIosBCWmNGopRCMxKFurDCiEQ5hUYkCiokukenq5BUSHSEjie4kNYY6ERZhQYkinZhBVyitEK4RHGF8OVUXiFYooJCsEQNhVCJKgqhEnUUAiUqKQRK1FIIk6imECZRTyFIoqJCkERNhUQ7+gFVFb6hn1BXIUCitkL9TtRWqC5RXSFpd6K+QmWJCIW6EhEKVSViFGpK7P8YPTnUJKIU6klEKdSTCAuoJRGnkGhLIyCuCys0EiIVqnQiVqGGRKxCjU4EB5SXiFYoLhHdhRWyCdueU6GNqEQLCmUlWlAoKxGd7QO5gDYUEo3FEqKTfSEVcOKeWgmpTkTnWkAmoB2FUp2ITtVAIqCVhbTmp0BCdKYl+ANa6sIK/k5EJ1qBO6A1hfydiM7TAm9AewqJfrEmRKdphTOgRYW8nYjO0gFfQJsKOTsRnaQTroBWFRKNmBKic/TAE3AdHaMHnk5Ep+iFI6BlhTydiM7gID2gbYUcEtEJnKQGHKEDOEldTtH1e5AW0HoXVqR1Irp6L0pXmCYRXbsn8QHtL6Q18RLRlXtTusJ4iei6AyhdYaxEdNVBxAT8iS46iBiJ6JoDKV1hjEShQl4mM6GRQwP+EqnisXpS5eaeyNjrBhS+Tj8G37iSGD4s4Jh9/lnjVfZDgVNLWCdyzz5fffLf9gX3JECFVxutszwd804TIpFz3vvRoHOeIe8L4yEKz1wP4To84JvMfzllm/LqyWO281u2+XwDbjHNNxl6TnjN9b5i305kmew57LP/dy5ZZvWbjEPhw2lQvor9OcO8fhLT59m9Ds5XMf2TPrXPPKkKD1I+N3acui/3WU7TZrg9T8hXkbovd8+wkzL8j7jLs0navtzdifFjX7K9g3UwuY8vwzV4tML5Ple+d+L35S6JkcP+mTrGDefpIbKW/mGjFM4kXji/Fr0v75cYcf3vST7gNmpf3jdguMKOox8fEfvyvksqUOH9evfRj4/r19CI3WMdBY1zofdcrcB9ebfEEIXHPkc/PsL25V2jBCg88T368RGyL++S6KvwL+iZDAP/fXn7AJ4Kb8KPfnxsnvkV2f4mU6//IJa9dQqe+/K2H/VQeAB/UEHFcN2jndre2ub8seSjHx/bzxESXQpf0ZdnE+f98lWJvV3Id/TjY+h42+7y9x/2fC/z0Y+P3n358nLarVDg6MfH6Y2vxC6FM5UPSEuh+355s/R2hXurf/WzyFHHvnzxe1oVmr48m5w/uiTerV6eY42jHx/TtkPk95dXFIremZBiZ6XVvn/HLV3H4ncmpPi9fL/88wvbjctT5c6EFEuHyE+JCwqdf5Q2z2C8uMGu/+1bYbaXZ5OFP+7Uh6GXj8uz5zUTufF1iHz/NP7NfFfPHgaj+y+JB+Vcnk3e73jM3lZYusvsl7s/T28X6/bartWjEQuDrfl/4nRzvYB5J80AAAAASUVORK5CYII=' style='height: 20px; ' >";
        break;

    default:
        echo "<img id='diary-icon' src='https://static.thenounproject.com/png/645172-200.png' style='height: 20px; ' >";  
        break;
}
        
         
        
          ?>  
            </td>  
<td><?php
        
        switch (true) {
    case $average3 <= 4:
        echo "<font color='green'>Low</p>";
        break;

    case $average3 >4 && $average3 <=8:
        echo "<font color='gold'>Mild</p>";
        break;
    case $average3 >8 && $average3 <=12:
        echo "<font color='orange'>Moderate</p>";
        break;
    case $average3 >12 && $average3 <=16:
        echo "<font color='red'>Severe</p>";
        break;

    default:
           echo "N/A";
        break;
}
        
         
          ?>  </td>        
          
        
      
    </tr>
    
    <tr>
        <td>Substance Abuse</td>
        <td style="text-align: center"><?php echo $average4;?></td>
        <td style="text-align: center"><?php echo $average8;?></td>
        <td style="text-align: center"><?php
        
        
        switch (true) {
    case $average8 < $average4:
           echo " <img id='diary-icon' src='https://www.kindpng.com/picc/m/10-101602_down-green-picture-arrow-png-green-down-arrow.png' style='height: 20px;' >";
        break;

    case $average8 > $average4:
        echo "<img id='diary-icon' src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAkFBMVEX/////AAD/kZH/+vr/+fn/pKT/pqb/qKj/oqL/5OT/xsb/qqr/nZ3/v7//rq7/paX/6en/l5f/UVH/zs7/Njb/urr/tLT/c3P/mZn/2Nj/S0v/09P/Rkb/y8v/KCj/HR3/fn7/8PD/a2v/Y2P/W1v/IyP/ERH/hIT/b2//XV3/39//QED/Ojr/Jyf/Ly//iYnilW/dAAAGSklEQVR4nN2d2ULbMBBFmSZpWAIN+1rCEihLC///d8WYJU5sa5uZO9J5LCDN7fEIySTx2poyJ9oTarNF1+gShCG6Qpcgy4iocIlvAekYXYQklUKiKboMQd4DlixxvU5YsMSPgPSALkSKyWfCYiV+BaQbdCkyfCsk2kAXI8JCwDIlLiosU2IjIN2iy+HnpJmwQIlLAcuTuKyQ6AldEjMrAUuTuKqwNIktAekRXRQnu20JS5I4aA1Ic3RdfLQrLEhih8KCJHYpJDpFl8ZEZ0DaQ5fGQ7fCQiR2dmExEvsUFiGxV2EREn/0J8xfokMh0Rm6wlRcConO0SWm4VSYvUS3wswlDj0C5i3RR2HWEj26sOICXWc8fgqJ9tGFxuLVhVlL9FWYrURvhdlK9FeYqUTPhbTmGV1tDCEKs5QY0IWZSgxTmKHEQIUZSgxVSPQbXXIYQQtpzV90zWGEK8xMYnAXZicxRmFWEqMUZiUxTiHRJrpwXyIW0poDdOW+xCrMRmJkF2YkMV5hJhITFGYiMUVhFhKjF9KaF3T9btIUEm2jA7hI6sIsJKYqNC8xsQszkJiu0LhEBoVEl+gUfXAoNC0xeSGtMSyRR6FhiSxdWGFWIpdCsxLZFBLdobO0w6fQqESmhbTmHzpNG5wKTUpk7MIKg53Iq5DoEB1oGWaFRDN0omW4FZqTyLqQ1hjrRH6FxiSyd2GFKYkSCk1JFFFoajmVUWhIosBCWmNGopRCMxKFurDCiEQ5hUYkCiokukenq5BUSHSEjie4kNYY6ERZhQYkinZhBVyitEK4RHGF8OVUXiFYooJCsEQNhVCJKgqhEnUUAiUqKQRK1FIIk6imECZRTyFIoqJCkERNhUQ7+gFVFb6hn1BXIUCitkL9TtRWqC5RXSFpd6K+QmWJCIW6EhEKVSViFGpK7P8YPTnUJKIU6klEKdSTCAuoJRGnkGhLIyCuCys0EiIVqnQiVqGGRKxCjU4EB5SXiFYoLhHdhRWyCdueU6GNqEQLCmUlWlAoKxGd7QO5gDYUEo3FEqKTfSEVcOKeWgmpTkTnWkAmoB2FUp2ITtVAIqCVhbTmp0BCdKYl+ANa6sIK/k5EJ1qBO6A1hfydiM7TAm9AewqJfrEmRKdphTOgRYW8nYjO0gFfQJsKOTsRnaQTroBWFRKNmBKic/TAE3AdHaMHnk5Ep+iFI6BlhTydiM7gID2gbYUcEtEJnKQGHKEDOEldTtH1e5AW0HoXVqR1Irp6L0pXmCYRXbsn8QHtL6Q18RLRlXtTusJ4iei6AyhdYaxEdNVBxAT8iS46iBiJ6JoDKV1hjEShQl4mM6GRQwP+EqnisXpS5eaeyNjrBhS+Tj8G37iSGD4s4Jh9/lnjVfZDgVNLWCdyzz5fffLf9gX3JECFVxutszwd804TIpFz3vvRoHOeIe8L4yEKz1wP4To84JvMfzllm/LqyWO281u2+XwDbjHNNxl6TnjN9b5i305kmew57LP/dy5ZZvWbjEPhw2lQvor9OcO8fhLT59m9Ds5XMf2TPrXPPKkKD1I+N3acui/3WU7TZrg9T8hXkbovd8+wkzL8j7jLs0navtzdifFjX7K9g3UwuY8vwzV4tML5Ple+d+L35S6JkcP+mTrGDefpIbKW/mGjFM4kXji/Fr0v75cYcf3vST7gNmpf3jdguMKOox8fEfvyvksqUOH9evfRj4/r19CI3WMdBY1zofdcrcB9ebfEEIXHPkc/PsL25V2jBCg88T368RGyL++S6KvwL+iZDAP/fXn7AJ4Kb8KPfnxsnvkV2f4mU6//IJa9dQqe+/K2H/VQeAB/UEHFcN2jndre2ub8seSjHx/bzxESXQpf0ZdnE+f98lWJvV3Id/TjY+h42+7y9x/2fC/z0Y+P3n358nLarVDg6MfH6Y2vxC6FM5UPSEuh+355s/R2hXurf/WzyFHHvnzxe1oVmr48m5w/uiTerV6eY42jHx/TtkPk95dXFIremZBiZ6XVvn/HLV3H4ncmpPi9fL/88wvbjctT5c6EFEuHyE+JCwqdf5Q2z2C8uMGu/+1bYbaXZ5OFP+7Uh6GXj8uz5zUTufF1iHz/NP7NfFfPHgaj+y+JB+Vcnk3e73jM3lZYusvsl7s/T28X6/bartWjEQuDrfl/4nRzvYB5J80AAAAASUVORK5CYII=' style='height: 20px; ' >";
        break;

    default:
        echo "<img id='diary-icon' src='https://static.thenounproject.com/png/645172-200.png' style='height: 20px; ' >";  
        break;
}
        
           
          ?>  
            </td>  
<td><?php
        
        switch (true) {
    case $average4 <= 4:
        echo "<font color='green'>Low</p>";
        break;

    case $average4 >4 && $average4 <=8:
        echo "<font color='gold'>Mild</p>";
        break;
    case $average4 >8 && $average4 <=12:
        echo "<font color='orange'>Moderate</p>";
        break;
    case $average4 >12 && $average4 <=16:
        echo "<font color='red'>Severe</p>";
        break;

    default:
           echo "N/A";
        break;
}
        
         
          ?>  </td>        
          
        
      
    </tr>
    
    </tbody>
    
  </table>

        </div> 
          
          <?php
    $query9="SELECT time FROM questionnaire WHERE user_username='$name' ORDER BY time DESC LIMIT 1";
    $res9=  mysqli_query($db, $query9);
    
    if ($res9->num_rows > 0) {
    $today=strtotime ("today");
    $datediff = $today - $res9;
    
    while($row = $res9->fetch_assoc()) {
        $ldate= $row["time"];
        $datediff = round(($today - $ldate) / (60  *60* 24));
        
         switch (true) {
    case $datediff > 1:
        echo "Last time you completed the questionnaire was  &nbsp;<strong> $datediff days ago</strong>.";
        break;

    case $datediff == 1:
        echo "Last time you completed the questionnaire was &nbsp;<strong>yesterday</strong>.";
        break;
    case $datediff == 0:
        echo "Last time you completed the questionnaire was today. \r\n <strong>  REMINDER</strong>: The questionnaire can only be completed once a day";
        break;
    
    default:
        echo "";
        break;
}


    }
} else {
        echo "Questionnaire has not been completed once yet";
}
    
   


    ?>
        </div>
      
      
      <hr>
      <?php
    $query8="SELECT score,datetaken FROM questionnaire WHERE symptom='subabuse' && user_username='$name' ORDER BY time DESC LIMIT 2";
    $res8=  mysqli_query($db, $query8);
      ?>
      
  <!--   ##########################################GUIDELINES TABLE#################################################### -->
    
      
       <div class="row">
        <div class="form-group col-md-12">
            <img id="diary-icon" style="height: 100px"src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOMAAADeCAMAAAD4tEcNAAAAllBMVEX39/chYJP7+vknmYkdXpL9/PrM2OIKW5Pu8fO/z9sXXJJwlbVPgKv09fatwdKAoL6MqMM9c6Dh6O0dZJmzxdXU3uddibAybp+6y9oAWJGbs8kNWY5pkbUQl4bn8O/b4+rc6+lJq51xuq9EeaV+vbQ4pZa019JdsqWRx78sapyftsx7nLtMrJ6SrcVijLHB3dmfzsel0crhyquDAAALnklEQVR4nO2dCXfiKhTHDWIS0Vh3TV07ttOqtZ33/b/ccwGyXRII2abD/53zTkdN4Be2e+EGWi0jIyMjIyMjI6N/R6gpKg/Qswenp/r1fOq6pWAidzqfEN8huHYRx5n0T+OiKTvu89HBVnOE/cl5Vyglmh6duqkSIpOLVxyh22tUGXI5/aIqLBr3V3XTCESOdiGQaHwgdbMIhSfdIiDdABGTahWhWd0+WcXbDD4W0POg9YoDfl2WdoWa9TkKcfrDqW0vL184VqnwyNVGHPgMsber1pbpLHlfvvqyPfrp7olEy5I8dTQZx8fHHcnC1r2VqtwFZo1u2gkqZMceRYvS0ex30JDQGlG4WZGZ9MlhTW4WSRu582hL/dLL2nhBkxlr3SaP3BFjiJcTckeR6urYOumgweNZOoX00GpJd2kxOs+JRoLsiNVFnnRyh+b4URuqbovXZndmrQTK1zlSWxc6Xev4WEBlyCfv8KiPzgAoJDSbFNXr0PqCD9pDkLrGtMlNwLRRP9winWcNxkdzJOfqq2pr9mhy+ABmn/X3tEH28meQ3oloPKbcSdMuh5xhxmm418FzjXLsEWGTKFmc8QIzLiOMfY2EmsvYXf0DjD+pHJ87oMFu/yTGcxfUM/k5jBZ2QEWt8r+cUUaGMSMhw1imDGOc8e+25aTkn34AI05bLSN+T2PdoymM+Pg1F6s31ZrqaApjP80/1FtubQ5jeRloDmN5ExGGsVQZxiIT0mBUWKACL89iTLtYKZ/yjN737+/wla3uVFZLF5olTmVErr18XNzdaWJKM6L9y2azedvzf88OsGsLyV8sgWJKYUR2b0F8evXkcIKeUeGMaP/WvultSz9wY0uE6cKTnQIjGvciswDYWegYOpKMDLG9+e/xQzT1FRCvCSQn34SMHXsRt9axr7FwJcfIEdubV8r4pBbsAvhGIkZkT4BQIQeeTS+MMUBsbz4o47NaVBbuSTPyBfSo/NzLFVKMAWJ7s6ef7dQY/aUsI3oSNHScbNIajNHsoDDiB/sOPfsK8ZH+GUgaZETBw3tcyn8iWPvJxRgfB0HEWxbXKR5fVF8DKGmYkTd0crxfe+CBLJNdJxdlkvE+Dr7veXmFEV8jpY3gOXwgDAccxGFGHgfhDMf3iz37wAJcRr2ul8ceizNu70jXwR4lET90RuJk0iDjmH644nFHiEae3IrWPwxaypmIM6I/mwfQA7JERJgR2Y8YUzwJQmnQJeiFsD9Xjp5LML5SxjukuKIWIJiRhtLgkQf/0CLKcZBixhtkmYgKjNFYHctJjkPpCcXb4zdnbL99l4mYn9HCaoF9yX71I4AM/fUKXqziLhbJqBb3lmQM1daMUpyJw1Jluvj8jIrmAGTnJCAhRDSepziMfYnOLwcjN3rITJMxDgmWopsagk4k4tuUGfHoxNIkSRNfkTFaXUFEtEz3HwF/sQBG9q1lqbRIgd/xmtndZPiPeJ3Z9eVg9DrMKVEZPwSMQUkKBo0s/1Eivi0PIwvTtLDCvIDQf6SQcCm2eECfqBgBf7EQRh7zqrA+ImR8lKR46EdDP81f7EkknYeRRQrihTRi2jzA7/e399/ip4Wm85FIfchfLISR159iGFHLS/Vjrt8LJVORmsBYtgyjYTSM8YQMY5kyjIbRMMYTMoxlyjAaRsMYT0ieEe33+/CvOuOZrMCZyAYyur/am/avbfDv3mQluZnDyvoCKBvHiLYv97mPd5a0N1cJCCCL5Fxh4xi3n3Sajs5+oK5ifE4y5r1pjNvPTXQqMvombbbwVzLpZjFuX+KT5uiiUlWvlXXdcMYAsb1hIR8ztbrqJxNoFCNrizfEX/zTs6+wOZTTT76fUScj2u63YWLeFiOIrdbzaCGtIbCMVSPj9vU6Dr4GKYgQW6jlygqcb62P0XuPjoOPcRFA1FZtjOg3XcuhkMJS1Fd9jGxR7gEJdzfFqH7GGyQqsRQ1GfEi/9ocq6t3yFIRczLSCF6VyI5kv/qeDF0pBTEnY2dwC6gjevEAHgAJIqKUwaKAtbnQ3cKMLbQ8HI9rlcBAKEY3AQkiesOJWGcJylRGywrfzgqXLfI8VynAE7Ll4pBwRV2nGayQ7abIGBKP0c33wi5or0Yh4Yqa4T8CNnh+RvabIhkjkHApomF6fA7RjM8pnzEEKehRs/zHv4CRQ4oGDWSnu1bA3EbjGJltLh4XU/uclcRebvUztrybj/UhvtIbHh1CHOI49/89/qZ/FDB2YHq/639sJ9riGa++8nabllPkjkXStwGsUeh2XVIWY9nKZ8vlScgwlinDaBjVEjKMZcowGka1hAxjmTKMhlEtIcMYVXSNDXl1rM2VzLh/e/kTuvLUF77DEtdhCOSuiYzoYxOa+0BPCmvl2Jn/FYzo/qIyi3lAdk0xD2UyPhBDsSuK8Tnr5jNSxFAMkuIeQcmTVJrGyBDrjyUrjTFA/OTJzFeW9PY54DvYdTKixNIXR2y/BLGd4/VEmnECvUtfJ+Ofz9i7nSDijVL6qK4dtF5YI+OvxxpAMA0cIH5uYxfrbIVYHyOie5Js3r7ZJ0JETdXHGMSuPNY6gu7mpVjEJjC275talYdYI+N/4WXy363yEGvsc7yXEOPms6S2eE+6vn41tL9TwAqVYsq781KhJTUyIgASRJzOhSG5h/L2QCiEEYB8AdZa0eXqP4pMt/L2siiIMQEJdjcZMfN+9qaw9drkUUioFGvbW6YwxggkPGhk+Y8SZy3W7VsFkIJxsZ69nor1HymkeOj3DmkFCb1D1jjGK+T7bY9S4dCfuvea359lj5D1M161/96nXjtbilTOHnqlzHVkztVVuxeiWe9IScgwlinDaBjVEjKMZap6xvKOsxEmXTEjOQljinUlNHmqZrRELxXp63gR5KxyxvKE/eTy6k9jvDZ2eGP4H8UoOEGlDEaEoE1Eewo7GeTUqjrGaa8P6PiTGM8qZ8MUpGoZeYzC6CAdHaWrw6JiRtruJrZ0kJu2vNMqN6O1CDEuJRnX9HgTlY32NYUGORgpj0WCAYfmXZbRajojP0+HBCsmOzq8Ze0JEDBW52DkYmzNaU/FD9Th20qRjDWUOusqGYJOTeR1zuB8K/YpYTPt7DQovMgYOlg5EtUDdzSEpvS9RbiORcIKg3J06YkA1sild6HQTtaBc4yxSmcY2RTiABZA5wtDjBydHu2A+qzyZp03x/smjfPbleXSDRoImDt2hEOMsbVjWx7cs8ofFHDyYEyM0cIVdjotelYLgQ6iQAMfZkRrVpC3vqNzphkXeC/hOzJGpVNaNNVh1Q6qZtFjHsOMXdaP3h7NmG3WcchMjjNCJzGWpaCeAbsEPkUWokOMLW9E83octzonWtoy0eCBDzWxqytJ1l84w/j6ZmytPbzujE70u1sQOjtGUGLDnFBHjY/dqibhuGVm+cPIKlhiK4xIk+UHyhy4nQA26XhqIaMCk4vWecMqYgVpOf0ZW7NDnd06HjHhhG2YDpucIDb/S8Z2GYcHXGd02bmoU4F2fIDAZG2Pr2m2XPs8SUywOBEGdmgXnrMeB3g/BNA80o05zmjeq0DnUZAo8Y/9dW++cJJTSDhmJrDi57VA6gzoREBNNTMBJJ4mwdDkComGgSROmJY49uwmNtA0UvEB1F1EvpaIhHk8G8WTqatUwjPsREOcsOxOaxH7sFmaJBjCXaRFBDPtQEEO1F6tqU7QpklhpyTbVA0g1+XPiecRgV4cXAZ5xSNZwtbNo24iJHzyKDdapfbGCj2ccQMhyQLeaZ+Pdaqnr45TI/nq0Gok2LqRj3XkrGZeI7ensh11+fLXItMZnVVM1eil00V6BHGVchZirxDZjyonaapGr3WfIYuxemH/mO7/zO+5zOfTI3e5XhDfqX4di1uxjk+OX1M3vaG5B584Ce9amhJ59nRwGdamwdR2M0NAkTcdnrQmLRBCHekXGAtWRzLGVToW1sjIyMjIyMjIyMjIyEhP/wP/PIsyixFFGQAAAABJRU5ErkJggg==" >

           
            <table class="table table-hover" style="text-align: left">
    <thead class="thead-light">
      <tr>
          <th colspan="5"><h3 style="padding: auto; text-align: center">My Personal Guidelines</h3></th>
        
      </tr>
      
    </thead>
    <tbody>
        <tr>
            <th>Mental illness</th>
            <th>My Condition</th>
            <th>What to do?</th>
            
        </tr>
        
        <tr>
            <td>Anxiety</td>
            <td><?php
                          include 'guidelines.php';
        
        switch (true) {
    case $average <= 4:
        echo " <img id='diary-icon' style='height: 100px'src='+pYOZ64ksDp2FJjASDC+rxs0J3X3H8NHV9Zn0O9BLWGoGv0OtgJGyC4e74YdHlBP4w5/oC/xjQ1qT4GPlberXC8VsfD3QpUYcflBy+gN9WAX6+mki8l3DbXAh8j9gq1kRBNb4dlYdbHo9igK94wSPAE3VpVPLoSKjVFry56iCoxI8QjqbT6ZUJz4Yaj7qUSKzdlHj/EjaNO4vSAVX4UeRH0MtVridc3xOIJcSToL+Wo6IRiPbO3PBdcu/0sMzP/8ScLdW+Mt9KHskB0RpcEnil/mV8W6IOD2OAz4Ud4fopw9s2JX4SJMD2Dyke4XL/l/BhBPGHEeCj+Ep+5WMrwy/X8vNDDr+UXlzml/B8xKV+lnV1WRLgekSa8vN8VfAEacDi+Cvix+LmacrX4mn/ZpBKBX5e0corw4N87ffM+E7a1MiKZ4NLIoH23uoe4LewXMBjE360kv1c8n2fivwa3GjxdFRkX5Jco4OZHh/CG2PY9T7G8fbu8fEuQUFazFDXV+PRJcDHOTzCXS1+nM/vV1dxCk/uSU/X6xekmpg/xuw25voSfwHw8RpcKHZaT4efKesqCrqs1qWlvcqEFUFPWnwCh0HxobijxoeRio38iKd2MMi8ypJ4QbTW4TfNzPZlPEJdJb6U4ZmcJU1Q1mWERhLAvEJ+Ac17kL+DoJfpE6vwIyUd3xVVT587QbDEIAPfA01pytvKj8UzBb6ntPzyu5pOa4yc9hVgHtgRjyqtyvh+yUgEjr60aguZV4sN8JqKZjF89odc0MvU75TwSuV/aZFqyasqGSYBXrpV4BEKC3imPA3002y0o4DRieyMB5Ko8Jn6KX6AQJrhodZPBP01+EasoJOQ1s7h+xhkGVFm+FuBX6SGJLIzXh1MUucX+GsMcnya6KKc7b3GZLOZVC407qaRuZJOMgrEd9kvRXzwpQXoSxxgP0D3dfU41OE1gVwUfhzP0/y0gEd40qp5QvVEDMwg0cQBpWgcn/TsNcDzDookXzgM3s5ZjzcmUfYYvN1Bf03X08eEGT6Lt/HVdJqvZ1GyWT5uY2hCvrDiprwi5KZPmWX4Tj7PR6DJpMDBhdUVvrLhpL6nHPXA+kjaXtVELKsb8GuzlAE1onM8KkEo8O2V5g68bLUWjUmv8BC2luBifWXAzx7eF3hdlYM3LOR7lcezPP6y7ojXw8nThwI/1rQxYEGnQcd87g5XvMHxqPRChg/VYRmhVSsNet4WPohPbh3wesdj0mX4rq6NEp+Pna7amxyPPqbP8KpCo4jPRS9HvNHxEM+6SFdiFvCwGx3x+ogn5Jrhr3WXOZ7Hl4ed8RbHQyzrIU2ZxfDfLy4uRHx5Ad7ieGy6jQ7aWhut6nL1ag77fu0S9R4scLbahQ5G2stsoVZEd1g0ReVph0L5jc32NO4hzfSC4S/BOwNZr7Oprd32VuVp0kOszNNcvgfW9xJxn//kkvDsjsdGHtJG/HT1KFs2J7M6IsG26ZJu7Y7Hor4JjxDvfAHzHjZJsn2oN12KzbkulkH82IwPxNQ6XTn2nEttB8cj1qX4juHGpFqFfHexRjyGv7bgcaq+U20DlHdwPAc8ipov0t/F8QTe5HqZ8+80tXCJeFRsrofSGMM7wLkBTo7nMPCQjD27NMAh4mV4fdTjEtxJvlsL3BxPRL2RzUtwvIYNcIh4sYvjiZjftQ5R379b10ELrMnOCS4ynj7fgxuj7Q1swX7waGSsdqCQmf320pHvio/axlqv1IJt5gRG+7vie6zWM4a9fAOyIGz0P1f82FznK0TyX48XdX7bnQ74BvUd8cHIPMdTCnuDZO59V+O3+Qx36BYluOBt3WZ9R/xATLBtYbcg6/3gs/l9uIPvyRz4Wjzter624xR4Mon2g8ealS1rs5v7wPvjDN92tb5/RuWySaXS0Aq7y/IovqqK9O8SyvDow1+o/PVvn4i808vfifz6ZBlPYFHVUvEI+m+/n3N5PjXLeypvvpr4eAjwoeFGif/9/C2T5zdu8mTCj+B6vnaBBdC/CvrxkRv9/QeD+r3c64Sug/IfUvypI/7PevdL93Gk73LGVvX3iu+Febx+keFH4LP3mNl7PGvNs098dFDEd3XL2j8AH/RLeKvz7xEvdxBIfNsSpfaHB9t3wPt7S+LZGx7uXoGbJ8yRf3/at9V48+DbFz63cyy3c8Vo/j3h8xuH8tuGBgb32xM+CvX40KD+fvBBftNaYc+WoejdPeP9WrZlbtNOGW/s/n9w/vHL831xx1h5v54++J19Ffy3Tuor0j0eFGnlzZLXev7TP49FvXNklX/9VqL7cenQhGKraPGdKeD/Saj/9tgm5z8p/K58ZEO1UTbW8SXeKgq8rzgwosKH5R3Sr8fj0j5NHf4g1PT/K/CaXdqaLeLq0u/leNxTH9XR7VAfquZdL8aXR5wFr5z4QPwunl+MdQ74g255AAD8x6MTo5z+nOEx0p+OMJzNCEsBUOI/ntiCXobHA8MJLePJlFnhUE6Gd8g6Au/rDW/FEwMESvxHe87l+GBgPhtmOxQ16gUqvNX2DI8j27Es+5GwmXTB3fA4MtrdEX8QztKDIjvg3/98NnQ4FOh0Ho82wN8Ff3J6+m+nE4muhyH74wA74k9On2/rjo91PwoazgYEf2zBn5we3f7H/TTsTgdhu+vb5z/+OD8+VuMJ+s3tt8UuT9z1HG7r+7fb5+Pzo9PTkxPAJXJC0N93Yr8AL9pQ//bu021Kv/307lt9ZzKT/wIzdCt5npRmtQAAAABJRU5ErkJggg==' >";
        break;

    case $average >4 && $average <=8:
        echo $mildanx;
        break;
    case $average >8 && $average <=12:
        echo $moderateanx;
        break;
    case $average >12 && $average <=16:
        echo $severeanx;
        break;

    default:
           echo "N/A";
        break;
}
        
         
          ?>  </td>
            <td><?php
    include 'guidelines.php';
        
        switch (true) {
    case $average <= 4:
        echo "<p>LOW?! Keep doing what you're doing!</p>";
        break;

    case $average >4 && $average <=8:
        echo $mildanx2;
        break;
    case $average >8 && $average <=12:
        echo $moderateanx2;
        break;
    case $average >12 && $average <=16:
        echo $severeanx2;
        break;

    default:
           echo "N/A";
        break;
}
        
         
          ?>  </td>
            
        </tr>
         <tr>
            <td>Depression</td>
            <td><?php
                          include 'guidelines.php';
        
        switch (true) {
    case $average2 <= 4:
        echo " <img id='diary-icon' style='height: 100px'src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAH4AAAB+CAMAAADV/VW6AAAA/1BMVEVU1oD/////38//ZGb/OTr/ycCa9LH/7ub/Vlf/Nzf/YGL/39H/XWD/nJX/yML/5dRG24LDg1lG1HhN2YL/Lzf/XWX/1ciYqmuwoHH/z8T/7+s/1njw+/P1/PfdzbT/PT7NdFLWgWp955yv6sFe2Ifo+e1y3JTS89yF4KKtk2F63Zqd5LHd9uVo2o6M4afK3LaM7qfKzqt+14+97czq3sX/kY3+e3r/5eH58+u42a/r7Nou02/rxbKi0Zml26a2z6PU582M1JTa3b6t0Z/mjXv/hoO+mXKhqXJnzHx5v3XqUkT/S06Nunf0QT3gaVDnalztuaz8pKT/Iyb/s7D+0tIe1uB0AAAJjklEQVRogcWbe2PaOBLAFVpCEqeQk9P0wDjdDQZygIEYGspCSEnubrOb3mvb7/9ZTi9bY1svEno3fwE2/mlGo5mRLKGDl8vnRa3WesX/iaCX/3VR9WpE/j/4cFHl+M/tdjv8X+LDfmc4WNYF/heMot71sNPvHrSI/Fj8qDNGqwDjgNCrFxTfihERH6+SNfv++Ufh2/0xxthntDuKrzL8BtNf8H29WWPS/RH4sD9AmIEY7IbhFxT/hTYIk/ZccPx1b9beM77bibnaqVxSOgM25hH5HjdFX9RaQ4yjoaMJnPDdsdSbiy/wFSJe4lPTZ3jaGTi4Hu0J3x0HPioIvmH4JsMvMQrW1Qy/5E0Nev094NtjXIIT7R/rGb4yJzdUJX4iLIVXA+sosODDDsJlOMEnAN+I/YjhF4z/EHB6crOu2aKyGT/q5eBxHKUfI4D3Nr5PPK9KGtLwvMqDGIjVOgtLxqhsxA9z8OiQyJX4ElQBfhIEHM/7gv7rjPpi7TX4UZS3++Eh4AeXEl+pYOZ64ksDp2FJjASDC+rxs0J3X3H8NHV9Zn0O9BLWGoGv0OtgJGyC4e74YdHlBP4w5/oC/xjQ1qT4GPlberXC8VsfD3QpUYcflBy+gN9WAX6+mki8l3DbXAh8j9gq1kRBNb4dlYdbHo9igK94wSPAE3VpVPLoSKjVFry56iCoxI8QjqbT6ZUJz4Yaj7qUSKzdlHj/EjaNO4vSAVX4UeRH0MtVridc3xOIJcSToL+Wo6IRiPbO3PBdcu/0sMzP/8ScLdW+Mt9KHskB0RpcEnil/mV8W6IOD2OAz4Ud4fopw9s2JX4SJMD2Dyke4XL/l/BhBPGHEeCj+Ep+5WMrwy/X8vNDDr+UXlzml/B8xKV+lnV1WRLgekSa8vN8VfAEacDi+Cvix+LmacrX4mn/ZpBKBX5e0corw4N87ffM+E7a1MiKZ4NLIoH23uoe4LewXMBjE360kv1c8n2fivwa3GjxdFRkX5Jco4OZHh/CG2PY9T7G8fbu8fEuQUFazFDXV+PRJcDHOTzCXS1+nM/vV1dxCk/uSU/X6xekmpg/xuw25voSfwHw8RpcKHZaT4efKesqCrqs1qWlvcqEFUFPWnwCh0HxobijxoeRio38iKd2MMi8ypJ4QbTW4TfNzPZlPEJdJb6U4ZmcJU1Q1mWERhLAvEJ+Ac17kL+DoJfpE6vwIyUd3xVVT587QbDEIAPfA01pytvKj8UzBb6ntPzyu5pOa4yc9hVgHtgRjyqtyvh+yUgEjr60aguZV4sN8JqKZjF89odc0MvU75TwSuV/aZFqyasqGSYBXrpV4BEKC3imPA3002y0o4DRieyMB5Ko8Jn6KX6AQJrhodZPBP01+EasoJOQ1s7h+xhkGVFm+FuBX6SGJLIzXh1MUucX+GsMcnya6KKc7b3GZLOZVC407qaRuZJOMgrEd9kvRXzwpQXoSxxgP0D3dfU41OE1gVwUfhzP0/y0gEd40qp5QvVEDMwg0cQBpWgcn/TsNcDzDookXzgM3s5ZjzcmUfYYvN1Bf03X08eEGT6Lt/HVdJqvZ1GyWT5uY2hCvrDiprwi5KZPmWX4Tj7PR6DJpMDBhdUVvrLhpL6nHPXA+kjaXtVELKsb8GuzlAE1onM8KkEo8O2V5g68bLUWjUmv8BC2luBifWXAzx7eF3hdlYM3LOR7lcezPP6y7ojXw8nThwI/1rQxYEGnQcd87g5XvMHxqPRChg/VYRmhVSsNet4WPohPbh3wesdj0mX4rq6NEp+Pna7amxyPPqbP8KpCo4jPRS9HvNHxEM+6SFdiFvCwGx3x+ogn5Jrhr3WXOZ7Hl4ed8RbHQyzrIU2ZxfDfLy4uRHx5Ad7ieGy6jQ7aWhut6nL1ag77fu0S9R4scLbahQ5G2stsoVZEd1g0ReVph0L5jc32NO4hzfSC4S/BOwNZr7Oprd32VuVp0kOszNNcvgfW9xJxn//kkvDsjsdGHtJG/HT1KFs2J7M6IsG26ZJu7Y7Hor4JjxDvfAHzHjZJsn2oN12KzbkulkH82IwPxNQ6XTn2nEttB8cj1qX4juHGpFqFfHexRjyGv7bgcaq+U20DlHdwPAc8ipov0t/F8QTe5HqZ8+80tXCJeFRsrofSGMM7wLkBTo7nMPCQjD27NMAh4mV4fdTjEtxJvlsL3BxPRL2RzUtwvIYNcIh4sYvjiZjftQ5R379b10ELrMnOCS4ynj7fgxuj7Q1swX7waGSsdqCQmf320pHvio/axlqv1IJt5gRG+7vie6zWM4a9fAOyIGz0P1f82FznK0TyX48XdX7bnQ74BvUd8cHIPMdTCnuDZO59V+O3+Qx36BYluOBt3WZ9R/xATLBtYbcg6/3gs/l9uIPvyRz4Wjzter624xR4Mon2g8ealS1rs5v7wPvjDN92tb5/RuWySaXS0Aq7y/IovqqK9O8SyvDow1+o/PVvn4i808vfifz6ZBlPYFHVUvEI+m+/n3N5PjXLeypvvpr4eAjwoeFGif/9/C2T5zdu8mTCj+B6vnaBBdC/CvrxkRv9/QeD+r3c64Sug/IfUvypI/7PevdL93Gk73LGVvX3iu+Febx+keFH4LP3mNl7PGvNs098dFDEd3XL2j8AH/RLeKvz7xEvdxBIfNsSpfaHB9t3wPt7S+LZGx7uXoGbJ8yRf3/at9V48+DbFz63cyy3c8Vo/j3h8xuH8tuGBgb32xM+CvX40KD+fvBBftNaYc+WoejdPeP9WrZlbtNOGW/s/n9w/vHL831xx1h5v54++J19Ffy3Tuor0j0eFGnlzZLXev7TP49FvXNklX/9VqL7cenQhGKraPGdKeD/Saj/9tgm5z8p/K58ZEO1UTbW8SXeKgq8rzgwosKH5R3Sr8fj0j5NHf4g1PT/K/CaXdqaLeLq0u/leNxTH9XR7VAfquZdL8aXR5wFr5z4QPwunl+MdQ74g255AAD8x6MTo5z+nOEx0p+OMJzNCEsBUOI/ntiCXobHA8MJLePJlFnhUE6Gd8g6Au/rDW/FEwMESvxHe87l+GBgPhtmOxQ16gUqvNX2DI8j27Es+5GwmXTB3fA4MtrdEX8QztKDIjvg3/98NnQ4FOh0Ho82wN8Ff3J6+m+nE4muhyH74wA74k9On2/rjo91PwoazgYEf2zBn5we3f7H/TTsTgdhu+vb5z/+OD8+VuMJ+s3tt8UuT9z1HG7r+7fb5+Pzo9PTkxPAJXJC0N93Yr8AL9pQ//bu021Kv/307lt9ZzKT/wIzdCt5npRmtQAAAABJRU5ErkJggg==' >";
        break;

    case $average2 >4 && $average2 <=8:
        echo $milddep;
        break;
    case $average2 >8 && $average2 <=12:
        echo $moderatedep;
        break;
    case $average2 >12 && $average2 <=16:
        echo $severedep;
        break;

    default:
           echo "N/A";
        break;
}
        
         
          ?>  </td>
        <td><?php
    include 'guidelines.php';
        
        switch (true) {
    case $average2 <= 4:
        echo "<p>LOW?! Keep doing what you're doing!</p>";
        break;

    case $average2 >4 && $average2 <=8:
        echo $milddep2;
        break;
    case $average2 >8 && $average2 <=12:
        echo $moderatedep2;
        break;
    case $average2 >12 && $average2 <=16:
        echo $severedep2;
        break;

    default:
           echo "N/A";
        break;
}
        
         
          ?>  </td>

            
        </tr>
         <tr>
            <td>Somatic disorder</td>
            <td><?php
                          include 'guidelines.php';
        
        switch (true) {
    case $average3 <= 4:
        echo "<p>Low</p>";
        break;

    case $average3 >4 && $average3 <=8:
        echo $mildsd;
        break;
    case $average3 >8 && $average3 <=12:
        echo $moderatesd;
        break;
    case $average3 >12 && $average3 <=16:
        echo $severesd;
        break;

    default:
           echo "N/A";
        break;
}
        
         
          ?>  </td>
        <td><?php
    include 'guidelines.php';
        
        switch (true) {
    case $average3 <= 4:
        echo "<p>LOW?! Keep doing what you're doing!</p>";
        break;

    case $average3 >4 && $average3 <=8:
        echo $mildsd2;
        break;
    case $average3 >8 && $average3 <=12:
        echo $severesd2;
        break;
    case $average3 >12 && $average3 <=16:
        echo $severesd2;
        break;

    default:
           echo "N/A";
        break;
}
        
         
          ?>  </td>

            
        </tr>
         <tr>
            <td>Substance Abuse</td>
            <td><?php
                          include 'guidelines.php';
        
        switch (true) {
    case $average4 <= 4:
        echo "<p>Low</p>";
        break;

    case $average4 >4 && $average4 <=8:
        echo $mildsa;
        break;
    case $average4 >8 && $average4 <=12:
        echo $moderatesa;
        break;
    case $average4 >12 && $average4 <=16:
        echo $severesa;
        break;

    default:
           echo "N/A";
        break;
}
        
         
          ?>  </td>
        <td><?php
    include 'guidelines.php';
        
        switch (true) {
    case $average4 <= 4:
        echo "<p>LOW?! Keep doing what you're doing!</p>";
        break;

    case $average4 >4 && $average4 <=8:
        echo $mildsa2;
        break;
    case $average4 >8 && $average4 <=12:
        echo $moderatesa2;
        break;
    case $average4 >12 && $average4 <=16:
        echo $severesa2;
        break;

    default:
           echo "N/A";
        break;
}
        
         
          ?>  </td>

            
        </tr>
        
    </tbody>
            </table>
        </div>
       </div>
            
        </div>
        <div class="form-group col-md-12">
          
        </div>
      </div>
            
      </div>
    </div>

  </main>
  <!-- page-content" -->

  <!-- page-content" -->
</div>
<!-- page-wrapper -->
<!-- partial -->

<script>
function showRSS(str) {
  if (str.length==0) {
    document.getElementById("rssOutput").innerHTML="";
    return;
  }
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else {  // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (this.readyState==4 && this.status==200) {
      document.getElementById("rssOutput").innerHTML=this.responseText;
    }
  }
  xmlhttp.open("GET","getrss.php?q="+str,true);
  xmlhttp.send();
}
</script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/esm/popper.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.1/js/bootstrap.js'></script><script  src="../JS/dashscript.js"></script>

</body>
</html>
