<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$lowanx=""  ;
$mildanx="Although often described as sub-clinical or clinically non-significant, mild anxiety can impact emotional, social and professional functioning. Mild anxiety symptoms may present as social anxiety or shyness and can be experienced in early childhood through to adulthood. If left unaddressed, mild anxiety can lead to maladaptive coping strategies or more severe mental conditions."  ;
$mildanx2="Though not a treatment for anxiety disorders, the following tips can help reduce symptoms of anxiety: Take care of your body by eating a well-balanced diet. Include a multivitamin when you can't always eat right.
Limit alcohol, caffeine, and sugar consumption.
Take time out for yourself every day. Even 20 minutes of relaxation or doing something pleasurable for yourself can be restorative and decrease your overall anxiety level.
Trim a hectic schedule to its most essential items, and do your best to avoid activities you don't find relaxing.
Keep an anxiety journal. Rank your anxiety on a 1-to-10 scale. Note the events during which you felt anxious and the thoughts going through your mind before and during the anxiety. Keep track of things that make you more anxious or less anxious.
Interrupt hyperventilation. If you begin to hyperventilate, exhale into a paper bag and inhale the air within the bag. This increases the amount of carbon dioxide you are inhaling, which can reduce the urge to hyperventilate. Inhaling from a bag will help relieve any dizziness or tingling you might feel ";
$moderateanx="People with moderate levels of anxiety have more frequent or persistent symptoms than those with mild anxiety, but still have better daily functioning than someone with severe anxiety or panic disorder. For example, people with moderate anxiety may report experiencing symptoms such as feeling on edge, being unable to control their worrying or being unable to relax several days or the majority of days in a week, but not every day. Although moderate anxiety symptoms are disruptive, people with moderate anxiety may have success in managing their anxiety with the help of a doctor or self-help strategies."  ;
$moderateanx2="If your worries, fears, or anxiety attacks have become so great that they’re causing extreme distress or disrupting your daily routine, it’s important to seek professional help.

If you’re experiencing a lot of physical anxiety symptoms, you should start by getting a medical checkup.";
$severeanx="Severe anxiety is intensely debilitating, and symptoms of severe anxiety meet key diagnostic criteria for clinically-significant anxiety disorder. People with severe anxiety typically score higher on scales of distress and lower on functioning. Severe anxiety symptoms also frequently co-occur with major depression, which can contribute to greater disability. Symptoms of severe anxiety are frequent and persistent and may include increased heart rate, feelings of panic and social withdrawal. These symptoms can result in loss of work and increased health care costs. In addition, individuals with severe anxiety may turn to alcohol and drugs as a means to cope with their symptoms.";

$severeanx2="If you’re experiencing panic attacks you should start by getting a medical checkup. Your doctor can check to make sure that your anxiety isn’t caused by a medical condition, such as a thyroid problem, hypoglycemia, or asthma. Since certain drugs and supplements can cause anxiety, your doctor will also want to know about any prescriptions, over-the-counter medications, herbal remedies, and recreational drugs you’re taking.

If your physician rules out a medical cause, the next step is to consult with a therapist who has experience treating anxiety disorders. The therapist will work with you to determine the cause and type of your anxiety disorder and devise a course of treatment.";









$lowdep=""  ;


$milddep="<p>Mild depression involves more than just feeling blue temporarily. Your symptoms can go on for days and are noticeable enough to interfere with your usual activities.

Mild depression may cause:

irritability or anger
hopelessness
feelings of guilt and despair
self-loathing
a loss of interest in activities you once enjoyed
difficulties concentrating at work
a lack of motivation
a sudden disinterest in socializing
aches and pains with seemingly no direct cause
daytime sleepiness and fatigue
insomnia
appetite changes
weight changes
reckless behavior, such as abuse of alcohol and drugs, or gambling
If your symptoms persist for most of the day, on an average of four days a week for two years, you would most likely be diagnosed with persistent depressive disorder. This condition is also referred to as dysthymia.

Though mild depression is noticeable, it’s the most difficult to diagnose. It’s easy to dismiss the symptoms and avoid discussing them with your doctor.

Despite the challenges in diagnosis, mild depression is the easiest to treat. Certain lifestyle changes can go a long way in boosting serotonin levels in the brain, which can help fight depressive symptoms.

Helpful lifestyle changes include:

exercising daily
adhering to a sleep schedule
eating a balanced diet rich in fruits and vegetables
practicing yoga or meditation
doing activities that reduce stress, such as journaling, reading, or listening to music
Other treatments for mild depression include alternative remedies, such as St. John’s Wort and melatonin supplements. However, supplements can interfere with certain medications. Be sure to ask your doctor before taking any supplements for depression.

A class of antidepressants called selective serotonin reuptake inhibitors (SSRIs) may be used in some cases. However, these tend to be more effective in people with more severe forms of depression. Recurrent depression tends to respond better to lifestyle changes and forms of talk therapy, such as psychotherapy, than medication.

While medical treatment may not be needed, mild depression won’t necessarily go away on its own. In fact, when left alone, mild depression can progress to more severe forms.</p>"  ;


$milddep2="Although not too severe, you might want to prevent the worsening of symptoms by: findingways to handle stress and improve your self-esteem, taking good care of yourself. Getting enough sleep, eating well, and exercise regularly. Reaching out to family and friends when times get hard.
Getting regular medical checkups, and see your provider if you don’t feel right.
Getting help if you think you’re depressed. If you wait, it could get worse.";


$moderatedep="<p>In terms of symptomatic severity, moderate depression is the next level up from mild cases. Moderate and mild depression share similar symptoms. Additionally, moderate depression may cause:

problems with self-esteem
reduced productivity
feelings of worthlessness
increased sensitivities
excessive worrying
The greatest difference is that the symptoms of moderate depression are severe enough to cause problems at home and work. You may also find significant difficulties in your social life.

Moderate depression is easier to diagnose than mild cases because the symptoms significantly impact your daily life.</p>"  ;


$moderatedep2="<p> The key to a diagnosis, is to make sure you talk to your doctor about the symptoms you’re experiencing.

SSRIs, such as sertraline (Zoloft) or paroxetine (Paxil), may be prescribed. These medications can take up to six weeks to take full effect. Cognitive behavioral therapy (CBT) is also used in some cases of moderate depression.</p>";







$severedep="Severe (major) depression is classified as having the symptoms of mild to moderate depression, but the symptoms are severe and noticeable, even to your loved ones.

Episodes of major depression last an average of six months or longer. Sometimes severe depression can go away after a while, but it can also be recurrent for some people.

Diagnosis is especially crucial in severe depression, and it may even be time-sensitive.

Major forms of depression may also cause:

delusions
feelings of stupor
hallucinations
suicidal thoughts or behaviors";

$severedep2="<p> Severe depression requires medical treatment as soon as possible. Your doctor will likely recommend an SSRI and some form of talk therapy.

If you’re experiencing suicidal thoughts or behaviors, you should seek immediate medical attention. Call your local emergency services or the National Suicide Prevention Lifeline at 800-273-8255 right away.</p>";


$lowsd=""  ;
$mildsd=" At this stage, the person is starting to get slightly worried about the possibility of being affected by health issues. These concerns come in the form of:

1.Pervasive thoughts about the seriousness of one's health condtion.

2. Persistently high level of anxiety about health or symptoms.

3. Excessive time and energy devoted to these symptoms or health concerns."  ;
$mildsd2="Symptomps are not too severe but managing stress can help eliminate the symptoms"  ;
$moderatesd="symptoms at this stage might include:

Pain. This is the most commonly reported symptom. Areas of reported pain can include chest, arms, legs, joints, back, abdomen, and other areas.
Neurological symptoms such as headaches, movement disorders, weakness, dizziness, fainting
Digestive symptoms such as abdominal pain or bowel problems, diarrhea, incontinence, and constipation
Sexual symptoms such as pain during sexual activity or painful periods
Usually, patients report experiencing more than one symptom. Symptoms can range from mild to severe."  ;
$moderatesd2="Because physical symptoms can be related to medical problems, it's important to be evaluated by your primary care provider if you aren't sure what's causing your symptoms. If your primary care provider believes that you may have somatic symptom disorder, he or she can refer you to a mental health professional."  ;
$severesd="The symptoms remain the same as moderate Somatic disorers, although the intensity of the pain or discomfort is much greater. The symptoms include:

Pain. This is the most commonly reported symptom. Areas of reported pain can include chest, arms, legs, joints, back, abdomen, and other areas.
Neurological symptoms such as headaches, movement disorders, weakness, dizziness, fainting
Digestive symptoms such as abdominal pain or bowel problems, diarrhea, incontinence, and constipation
Sexual symptoms such as pain during sexual activity or painful periods
Usually, patients report experiencing more than one symptom.";



$severesd2="If the pain felt, either psychological or physical, is persistent try to get in contact with medical professional as soon as possible";



$lowdsa=""  ;
$mildsa="In the prodromal stage, the person begins to drink alcohol as a coping mechanism and starts to display certain symptoms, such as increasing consumption of alcohol, frequent hangovers, and blackouts. The presence of blackouts signifies this stage from the prior stage. Jellinek believed that at this stage, the individual still exhibited a certain amount of control over their alcohol use despite these very serious symptoms."  ;
$mildsa2="At this stage, you might want to evaluate what events or situations bring you to resort to this activity or drug, identify them and see what personal step you might have to take";
$moderatesa=" When the person reaches the crucial phase of alcoholism, several events have occurred (loss of control is the defining factor in this sta ge):
The person no longer has control over their drinking. When they begin drinking alcohol, they cannot stop.
Because the person has lost control of their alcohol use, they make excuses for their drinking.
The person attempts to control their drinking by establishing specific guidelines as to when they can and cannot use alcohol, although these guidelines rarely work.
The person begins to experience problems with physical health and mental functioning, and may even be hospitalized.
The person begins to use alcohol just to get through the day, such as taking a drink first thing in the morning, having a set drinking routine at work, and drinking at specific time periods.
The above routine is often an attempt to cope with the development of both tolerance to alcohol and withdrawal symptoms (the onset of physical dependence)."  ;
$moderatesa2="Regardless of whether you wish to
abstain from or reduce your alcohol consumption, the help of
other people is important. One of the strongest predictors of
changing a drinking pattern is the availability and use made of
support from people who want you to succeed. Your support
network can be made up of family, friends and/or professional
services.";
$severesa="In this final phase, the individual presents in the stereotypical severe alcoholic fashion. The person no longer has any control over their alcohol use; they have a number of physical problems that can include tremors; any significant period of time without alcohol results in significant withdrawal; the person often develops delirium tremens (DTs) during withdrawal where they have hallucinations and become very confused; the individual goes on prolonged alcoholic benders; the person always has alcohol nearby or on their person; and the person’s life revolves around their use of alcohol.";
$severesa2="At this stage of substance abuse, you might be considered addicted to said activity or substance. It might prove very difficult for an addicted individual to break the cycle of compulsion without assistance. Fortunately, there are many effective professional treatment programs that can help. If you feel like this describes your condition, please find external help.";