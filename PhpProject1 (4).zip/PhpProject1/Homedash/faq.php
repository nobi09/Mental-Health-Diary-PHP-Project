<?php
include '../Config/connection.php';
include '../Homedash/sidebarnav.php';

?>
  <!-- sidebar-wrapper  -->
  <main class="page-content" style="background-color: #F9F7F6;">
      
      <div class="row" style="background-color: #F9F7F6;">
          <div class="col">
              Jump to:
              <ul>
                  <li><a href="">Top of the page</a></li>
                  <li><a href="#anxiety">Anxiety</a></li>
                  <li><a href="#depression">Depression</a></li>
                  <li><a href="#sdisorder">Somatic symptom Disorder</a></li>
                  <li><a href="#addiction">Addiction</a></li>
              </ul>
          </div>
  
<div class="col-8" style="padding: auto; text-align: center"><img id="diary-icon" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPkAAADLCAMAAACbI8UEAAAAe1BMVEUAAAD///9VVVXU1NRjY2MuLi60tLQZGRl8fHxra2sWFhbv7++dnZ0SEhL39/f4+Pjj4+PLy8ukpKRaWlrY2NhycnJKSkrFxcW+vr6Li4u7u7smJiYxMTGZmZnx8fE/Pz+tra03NzeEhIQgICALCwuJiYmSkpJGRkZ/f38vQnwyAAAI6klEQVR4nOWd63qiMBCGQV1bF8+K1dpW27p17/8KFzyHTAJkviQs+X72aSFvgWROmUSxWtP1e9r5NTpEFnT4Pg42+6Xm7rYVKX4+6Q9sAEtazadOee+iyWc9J9hn7fqOmc+iyF9/OeQ+6X3iHJwgn21dc+eaeycfL3xwZ9q6nu0K5K+euHNtfJI/ewTPprqxL/LJzit4Jpcr3AP5+Mk3eBR1fZCPrdhqdeUO/UY+acATz+Xshb+Re//Gr/pwTO5iVh89VdBh55bc5jr+lg5fu4kH+1SvM/mHLerFfNk45IvO5HZM1r8zz3BanchfLGCnjcaOL+TfaOzRvKnv+F05eR/MvX31TVVFOTk2EHHwE2KprYx8BgV/901UVRk5Mua2cGWB8RXFYyD4f/GBXxQB57eV08gCV1EMi6v/+GappyhGgb/4RqmpaAoC95UqMVa0hnBv9Z/4dD3fpL1Fx74WvXQzXFdxk6J3BPin+gbj9dcn4hY1tX3uJyXkKeA2SvDxfgW4vKl2cx181OHf4Zfi2l2XeUlaC/W8G/GN9gP9Ua19vOSytio3Ihqxr02+Ut03wKgxeqKfO//CVIT8w1dektaKejjsq1Lp3z37qmgRo+ReskeAN+uBnyX7FNwrytxT/sxhRcX8PPNy8kduI5qJ0SuS/Pk/+MTvmgPJJfA5ZoyW9A4jl0Iwe8gA7WkOIpdyfxi/z6ZeMeTF2XKJGp9FLRHkiwI4MJTZ2fS7yWkFHifTWf8HaCGMAeTFRw5ySA8byh5eDkH5kBWfvFMY2xAysIU6EbnExEqHbPLCECHxvIU+mpcgwihX39L4778LozryhzQqTzxPAeU8KyZ5wfsBLGhpKXcugK205pEXfB9+Md2+EjjCIxqxyAtL2p47mjolgOzQYZ9DXohusR95rRpv7iT/xCEXo47sorKaRZ/cOf7FnPwojoQ7sa/rgbNz/h1z8qEwDu5ablBnwQxpJ8bk4mf5wxtG0QGoIqaTMDQmF4fBLJM2AOdW97yZkoufOfNlNywZ5NUoJ4bkX8IYeGbVwAw8nrDu2jckF1dz3kRrXE2159w1NSQXl1/OCKI/Cq7lcJB7J9vORpkO5dx2ZPjXwnNKOCMo2v+XS26E30lpC4/1lRkuDsIAWLkF8iv/kn6tR/2DWF+6WdBQ9M1Z/3piYk/I0mtqBeDY72ZutRhu3pT/gVoyjmqNJD53TlDA7HmJCVTOf5542ZVun5wE5xhyZs9LjJ5w3GU5HKE2UIiENaMww8zdExOJHEdNijjqFgr5oTPsOLM3VSTnuE0Syx/NL8svCGNyNTO/RHJGCmArseiCO3LOmrGg9oxqo2Dk0gSndX6KuY047prfumdUDwcjl0xXbbH9qvjbHC+xZ1QDCSOXSpa0a408ubPITWZ3GLlUn6idceWtAyxyk1pnGLlkkmrzsbIVx/rOTSxAGLkUbNaukBI4b243eWFg5JL3qTPKiH0yrPXcxEOHkUsmnK5/kQzOyTj0jPYuwcgle1RDTkUnGFuJM3KDzBCMXIrBqckp/5wTDcrIDSIbMHIp0qIi/yaLKfbmd87JDV533HeeiBoryL8obl4/lJy8/qIII6+mgyLTyspw5OT1/Xu35LKLdhErjX4ir23MOCVXJp94JZcn8toP3SG5JvfEK5M6k9fNS7oj15QUMCsPz+R1M2OuyHua7aXc8uILec013RG5rk6M3fXoQl7T6XFDrsurj9lFcVdyIpWlkRNyHfgHv5ndjbxWvsAFue5VR1QX38nrLG0OyOU4612QniAP5JPqLp8Dck25N6TU+5E8nlRGsE+ufuRd0BbInhDpqPqt2ydXteSZYB54VCSvOsPbJ1eUDQGbNhbIK67r9snpBw7oDHFTkTyeVHH9rJPLeaQYtFPmJok8c1/KSayTU5WwWHCKPPPXy5Z26+SEb8oreZRFksdxycrhgxx9YIaC/Lf+rzyQg9/1/4icVXpGyYxcTGo6IYffxIh8b3lQFDn8FibkxZymC3J842kDcin87YKcV09NqT65bGQEQn6UfzkMcrl0LxRyqsA+CHIyRhQCOb2dJAByxSai9pOrIuCtJ1e2bW47ubJyoe3kVNfDiyx0N20QOWG63QToJFOURI6ORVUmV3XxPclCA+O35zRNB4O8B/bquNt9vuG/qLQaubZTt/8exib6qkSu74r918/QmRpWIS/p9YJpEuZa/QrkZd0Qmt8DkdKsnLz0SB14QNiJklLyCr1eLIzr96gg+B0UZ2HfydWm2134ZU1qmAZfzxdl5BrT7S5mIx1C9m24YQk5mc2VxNg7pZB98qWeXGu6PQg9LAfkqjPvL+RVz1GCFa9cZZ38S09ecqDJXdgT2iIH5F0teY02fegjlW2T581R1OR1GllBDvJ5kG3yuY681mmIyNPpctkmn2jIh+TPlQL7a5bJN7GSPPpbDxyd5bVMPlGT1+/Zhq3msEt+jiKbtSIkhByaZfIYSw49R9wq+QuYHHryjk3yqxOGI0eubDbJrzvBcORIG1Yix/1bb7t7geRAS243H4qChQDudgqSHF6bitdDsAdKbiPdAtVjpAVLztwfbFtCdhBM3uinLsbW0OSNPFDvrEINI5y83g5Xhyp26cCTY+1YmKQdcBbI46QZZ8Q+6lOOKdogx0enuKLiLHbI46RJE92CDCJbIo/jblOW9qOiD4818owduZnSVB3lSS8WybN3/sf7qbGqTc2WyTMtf/xO9OrguW3yTOPZcODtTHCv5GdNkuWyi9SyUhPIBpBbUJVwRTvJq2SvW0peoTFGW8nL66xbS17aP6q15KWB+PaSl/WJazF5SSOYNpPH+2DJtbn7dpPrLJqWk2ssmraTq/fMtZ5cWQXeenKlRdN+cpVFEwC5YiNRCOT0QR1BkJMWTRjkVLVKIORE3UIo5LJFEwy5VDcXDLm0VTQc8qJFExB5waIJiVy0aIIiF85cDYv80aIJjPzBogmN/G7RBEc+Dpb8ZtGER35tBxAg+cWiCZH8bNEESX6yaMIkzy2aQMnjY7Dk8UF9cFXLyRN13es/YGiUaV/QbscAAAAASUVORK5CYII=" >
    <h1>Mental Health FAQ</h1>
    <hr><h2 id="main-heading">What is mental health?</h2> 
    <p id="main-intro"style="padding: auto; text-align: left"> Mental health refers to cognitive, behavioral, and emotional well-being. It is all about how people think, feel, and behave. People sometimes use the term “mental health” to mean the absence of a mental disorder.

Mental health can affect daily living, relationships, and physical health.

However, this link also works in the other direction. Factors in people’s lives, interpersonal connections, and physical factors can all contribute to mental health disruptions.

Looking after mental health can preserve a person’s ability to enjoy life. Doing this involves reaching a balance between life activities, responsibilities, and efforts to achieve psychological resilience.

Conditions such as stress, depression, and anxiety can all affect mental health and disrupt a person’s routine.

Although the term mental health is in common use, many conditions that doctors recognize as psychological disorders have physical roots. </p>
</div>
    <div class="col"></div>
</div>
<div class="row"id="anxiety">
<div class="col">
              Jump to:
              <ul>
                  <li><a href="">Top of the page</a></li>
                  <li><a href="#anxiety">Anxiety</a></li>
                  <li><a href="#depression">Depression</a></li>
                  <li><a href="#sdisorder">Somatic symptom Disorder</a></li>
                  <li><a href="#addiction">Addiction</a></li>
              </ul>
          </div>
    <div class="col-8" ><h2 class="mheading"><span class="text-primary">Anxiety</span></h2>
        <h3>What is an anxiety disorder?</h3>
        <p>Anxiety is a normal human emotion. Many people feel anxious, or nervous, when faced with a problem at work, or before taking a test or making an important decision. Anxiety disorders, however, are different. They can cause such distress that it interferes with a person's ability to lead a normal life.</p>
        <br>
        <p>An anxiety disorder is a serious mental illness. People with anxiety disorders respond to certain things or situations with fear and dread, as well as physical signs of anxiety such as a pounding heart and sweating. For people with anxiety disorders, worry and fear are constant and overwhelming, and can be crippling. An anxiety disorder is diagnosed if the person's response is not appropriate for the situation, if the person cannot control the response or if the anxiety interferes with normal functioning. Anxiety disorders can get worse if not treated; however, effective treatments are available.

</p>
<br>
<h4>What are the types of anxiety disorders?</h4>
        <p>There are several recognized anxiety disorders, including the following:</p>
        <h4>Panic disorder</h4>
        <p>People with this disorder have feelings of terror that strike suddenly and repeatedly with no warning. Other symptoms of a panic attack include sweating, chest pain, palpitations (unpleasant sensations of irregular heartbeats) and a feeling of choking, which might make the person feel like he or she is having a heart attack or "going crazy."</p>
        <h4>Post-traumatic stress disorder (PTSD)</h4>
        <p>PTSD is a condition that can develop following a traumatic and/or terrifying event, such as a sexual or physical assault, the unexpected death of a loved one, or a natural disaster. People with PTSD often have lasting and frightening thoughts and memories of the event, and tend to be emotionally numb.</p>
        <h4>Social anxiety disorder</h4>
        <p>Also called social phobia, social anxiety disorder involves overwhelming worry and self-consciousness about everyday social situations. The worry often centers on a fear of being judged by others, or behaving in a way that might cause embarrassment or lead to ridicule.</p>
        <h4>Specific phobias</h4>
        <p>A specific phobia is an intense fear of a specific object or situation, such as snakes, heights or flying. The level of fear usually is inappropriate to the situation and might cause the person to avoid common, everyday situations.</p>
        <h4>Generalized anxiety disorder</h4>
        <p>This disorder involves excessive, unrealistic worry and tension, even if there is little or nothing to provoke the anxiety.</p>
        <br>
        <h3>What causes anxiety disorders?</h3>
        <p>The exact cause of anxiety disorders is not known; but anxiety disorders — like other forms of mental illness — are not the result of personal weakness, a character flaw or poor upbringing. As scientists continue their research on mental illness, it is becoming clear that many of these disorders are caused by a combination of factors, including biology and environmental stresses.</p>
        <p>Like certain illnesses, such as diabetes, anxiety disorders might be caused by chemical imbalances in the body. Studies have shown that severe or long-lasting stress can change the balance of chemicals in the brain that control mood. Studies also have shown that anxiety disorders run in families, which means that they can be inherited from one or both parents, like hair or eye color. In addition, certain environmental factors — such as a trauma or significant event — might trigger an anxiety disorder in people who have an inherited susceptibility to developing the disorder.</p>


    </div>
    
<div class="col"></div>
</div>
      
      
      <hr>
      
<div class="row"id="depression">
<div class="col">
              Jump to:
              <ul>
                  <li><a href="">Top of the page</a></li>
                  <li><a href="#anxiety">Anxiety</a></li>
                  <li><a href="#depression">Depression</a></li>
                  <li><a href="#sdisorder">Somatic symptom Disorder</a></li>
                  <li><a href="#addiction">Addiction</a></li>
              </ul>
          </div>
<div class="col-8" ><h2 class="mheading"><span class="text-primary">Depression</span></h2>
        <h3>What is an depression?</h3>
        <p>Nearly everyone has felt depressed, sad, or blue at one time or another. A depressed mood is a normal reaction to loss, life's struggles, or injured self-esteem. Sometimes, however, depression becomes intense, lasts for long periods, and prevents a person from leading a normal life. If left untreated, depression can get worse, sometimes lasting for years. It can even result in suicide. It is important to recognize the signs of depression and seek help if you see signs of depression in you or a loved one. It is important to know that depression CAN be treated successfully.</p>        <br>
<br>
<h3>What are the types of depression?</h3>
<p>Major depressive disorder (or major depression): A person with this type of depression feels a profound and constant sense of hopelessness and despair. The symptoms of major depression interfere with the person's ability to work, sleep, study, eat, and enjoy themselves, even activities which had previously been pleasurable. This disabling type of depression may occur only once in a lifetime, or more commonly, occurs several times in a lifetime.</p>        <h4>Panic disorder</h4>
<p>Minor depression: A person with this type of depression has symptoms for longer than two weeks at a time, but does not meet the criteria for major depression.</p>
<p>Dysthymic disorder (or dysthymia or chronic depression): In dysthymia, the main symptom is a low mood on most days for a long period of time. Other depression symptoms may be present, but are not as severe as in major depression.</p>
        <h3>What causes  depression?</h3>
        <p>Depression may result from various factors in a person's life, including:</p>
        
        <li>High levels of stress</li>
        <li>Life transitions</li>
        <li>Loss</li>
        <li>Physical illness</li>
        <li>Family history of depression</li>
        <li>Imbalances in the chemicals that the body uses to control mood</li>
        <li>Certain medicines</li>
        <li>Lack of social support</li>
        <li>Lack of good coping skills</li>
        <li>History of traumatic experiences</li>

            
        

    </div>
        <div class="col"></div>
</div>
    
    
    <hr>
      
<div class="row"id="sdisorder">
<div class="col">
              Jump to:
              <ul>
                  <li><a href="">Top of the page</a></li>
                  <li><a href="#anxiety">Anxiety</a></li>
                  <li><a href="#depression">Depression</a></li>
                  <li><a href="#sdisorder">Somatic symptom Disorder</a></li>
                  <li><a href="#addiction">Addiction</a></li>
              </ul>
          </div>    
    <div class="col-8" ><h2 class="mheading"><span class="text-primary">Somatic Disorder</span></h2>
        
        <h4>What is a somatic symptom disorder?</h4>
        <p>Somatic symptom disorder is a disorder in which individuals feel excessively distressed about their health and also have abnormal thoughts, feelings, and behaviors in response to their symptoms. There are different subtypes of the disorder based on the patient’s complaint. The disorder causes a disruption in the patient’s normal functioning and quality of life.

        </p>   
        <p>Although a person with somatic symptom disorder reports symptoms, the symptoms may have no medical explanation. Even when there is a medical cause, the person’s worry is out of proportion to the symptom. The distress causes the patient to visit multiple healthcare providers and to have many medical tests and unnecessary procedures.</p>   
        <br>
        <h4>Who is affected by somatic symptom disorder?</h4>
        <p>Women are ten times more likely to report somatic symptoms than men. This is explained by the fact that the disorder is often related to childhood abuse and trauma to which women are more often exposed then men. Somatic symptom disorder can appear in any age group.</p>        

        <h4>What causes somatic symptom disorder?</h4>
        <p>Researchers believe there are many factors including biological susceptibility (it’s more common in women), exposure to emotional stress in childhood, and psychological factors such as learned ways of thinking in the context of a person’s social environment. The main factors include:</p>                
        <li>Childhood physical and sexual abuse.</li>
        <li>Poor awareness of emotions/emotional development during childhood. This can be the result of such things as parental neglect or lack of emotional closeness.</li>
        <li>Excessive anxiety and attention to bodily processes and possible signs of illness; low pain threshold.</li>
        
        


    </div>
                <div class="col"></div>

</div>
    
    
    
    <hr>
      
<div class="row"id="addiction">
<div class="col">
              Jump to:
              <ul>
                  <li><a href="">Top of the page</a></li>
                  <li><a href="#anxiety">Anxiety</a></li>
                  <li><a href="#depression">Depression</a></li>
                  <li><a href="#sdisorder">Somatic symptom Disorder</a></li>
                  <li><a href="#addiction">Addiction</a></li>
              </ul>
          </div>

    <div class="col-8" ><h2 class="mheading"><span class="text-primary">Addiction</span></h2>
        <h3>What are addictions?</h3>
        <p>Addictions are compulsions (irresistible urges) to use and abuse things excessively, until they become destructive. These compulsions are very powerful and produce a life-threatening process that can go on indefinitely and can end in disability or death for the sufferer, and cause pain and suffering for loved ones.</p>        <br>
        <p>Addictions can cause major life problems, such as:</p>
        <li>Loss of a job and financial trouble;</li>
        <li>Making negative personality traits even worse;</li>
        <li>Loss of other interests;</li>
        <li>Relapsing over and over, possibly ending in death.</li>
        <br>

        <p>These behaviors are often shaped by genetics and the person’s family. Addiction’s problems include loss of control, unpredictability, and unwanted consequences, as well as psychological and physical destruction.</p>
<br>
<h4>Who can become addicted?</h4>
        <p>Addiction is the most common public mental health problem in the United States. Nearly anyone can become addicted; approximately 22 percent of the general population in the United States can expect to have a significant problem with substance misuse or abuse at some point in their lives.</p>       
        </div>
    
<div class="col"></div>
</div>
     
<div class="row">
      <div class="col"></div>
  <div class="col-8" style="padding: auto; text-align: center"> <h2 class="mheading">We Need To Talk About <span class="text-primary">Mental Health (VIDEO)</span></h2> 
             
<iframe width="560" height="315" src="https://www.youtube.com/embed/TFbv757kup4" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>            </div>
  <div class="col"></div>
</div>
  </main>
  <!-- page-content" -->
</div>
<!-- page-wrapper -->
<!-- partial -->
  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/esm/popper.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.1/js/bootstrap.js'></script><script  src="./dashscript.js"></script>

</body>
</html>
